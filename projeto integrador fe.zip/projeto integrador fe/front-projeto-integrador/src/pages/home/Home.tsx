import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Certifique-se de importar seu arquivo CSS corretamente

const Home: React.FC = () => {
  return (
    <body>

      <div className="container"> 
        <header className="cabecalho">
          <div className="logo-menu">
            <div className="logo">proBARBER</div>
            <button className="menu-button-right">&#9776;</button>
          </div>
        </header>
        
        <main>
            <p className="mensagem">Tela de Home</p>
            <Link to="/" className="botao-voltar">Voltar</Link>
        </main>
      </div> 
      
    </body>
  );
};

export default Home;
