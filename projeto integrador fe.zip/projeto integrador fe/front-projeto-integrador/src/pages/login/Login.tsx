import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import './Login.css';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");
  const [error, setError] = useState("");

  // Função para lidar com o envio do formulário
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Lógica de validação de usuário e senha
    if (usuario === "usuario" && senha === "senha") {
      navigate('/Home'); // Navegar para a rota Home após o login bem-sucedido
    } else {
      setError("Usuário ou senha inválidos");
    }
  };

  return (
    <div className="login">
      <h1 className="logo">
        <span className="pro">pro</span>BARBER
      </h1>
      <form onSubmit={handleLogin}>
        <div className="ajuste">
          <div className="cont_user">
            <h2 className="usuario">
              Usuário
            </h2>
            <input
              className="inserir-usuario"
              type="text"
              placeholder="  Insira seu usuário"
              value={usuario}
              onChange={(e) => setUsuario(e.target.value)}
            />
          </div>
          <div className="cont_senha">
            <h2 className="senha">
              Senha
            </h2>
            <input
              className="inserir-senha"
              type="password"
              placeholder="  Insira sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />
          </div>
        </div>
        <div className="botao">
          <button className="botao-entrar" type="submit">Login</button>
        </div>
        {error && <p>{error}</p>}
      </form>
    </div>
  );
}

export default Login;
